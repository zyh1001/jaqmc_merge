# Copyright (c) 2026 ByteDance Ltd. and/or its affiliates
# SPDX-License-Identifier: Apache-2.0

from . import HallConfig as HallSphericalConfig

__all__ = ["HallSphericalConfig"]
