# Copyright (c) 2026 ByteDance Ltd. and/or its affiliates
# SPDX-License-Identifier: Apache-2.0

from . import HallSystemConfig

__all__ = ["HallSystemConfig"]
